# 📝 NoteVault — MERN Notes App with RBAC

A full-stack note-taking application built with MongoDB, Express, React, and Node.js, featuring Role-Based Access Control (RBAC).

---

## 🗂️ Project Structure

```
notes-app/
├── backend/                  # Express + MongoDB API
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── notesController.js
│   │   └── usersController.js
│   ├── middleware/
│   │   └── auth.js           # JWT protect + role authorize
│   ├── models/
│   │   ├── User.js
│   │   └── Note.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── notes.js
│   │   └── users.js          # Admin-only routes
│   ├── .env.example
│   ├── package.json
│   └── server.js
│
└── frontend/                 # React app
    ├── public/
    │   └── index.html
    └── src/
        ├── components/
        │   ├── layout/
        │   │   ├── Layout.js + Layout.module.css
        │   │   └── LoadingSpinner.js + LoadingSpinner.module.css
        │   └── notes/
        │       ├── NoteCard.js + NoteCard.module.css
        │       └── NoteModal.js + NoteModal.module.css
        ├── context/
        │   └── AuthContext.js
        ├── pages/
        │   ├── LoginPage.js
        │   ├── RegisterPage.js
        │   ├── NotesPage.js
        │   ├── AdminPage.js
        │   ├── AdminUserNotesPage.js
        │   └── AuthPage.module.css
        ├── utils/
        │   └── api.js         # Axios instance + all API calls
        ├── App.js
        ├── index.js
        └── index.css
```

---

## 🚀 Getting Started

### 1. Clone & Install

```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 2. Configure Environment

```bash
# In /backend, copy and edit .env
cp .env.example .env
```

Edit `backend/.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/notes-app
JWT_SECRET=your_super_secret_key_here
JWT_EXPIRE=7d
```

### 3. Run the App

```bash
# Terminal 1 — start backend
cd backend
npm run dev

# Terminal 2 — start frontend
cd frontend
npm start
```

Frontend: http://localhost:3000  
Backend API: http://localhost:5000/api

---

## 🔐 Roles & Permissions

| Feature                    | User | Admin |
|----------------------------|------|-------|
| Register / Login           | ✅   | ✅    |
| Create own notes           | ✅   | ✅    |
| Edit / Delete own notes    | ✅   | ✅    |
| View all users' notes      | ❌   | ✅    |
| Edit / Delete any note     | ❌   | ✅    |
| View all users (admin panel)| ❌  | ✅    |
| Change user roles          | ❌   | ✅    |
| Activate / Deactivate users| ❌   | ✅    |
| Delete users               | ❌   | ✅    |

> **Note:** The first admin must be set manually in MongoDB, or you can temporarily allow role selection in the register endpoint.

---

## 📡 API Endpoints

### Auth
| Method | Endpoint             | Access  | Description        |
|--------|----------------------|---------|--------------------|
| POST   | /api/auth/register   | Public  | Register user      |
| POST   | /api/auth/login      | Public  | Login user         |
| GET    | /api/auth/me         | Private | Get current user   |
| PUT    | /api/auth/password   | Private | Change password    |

### Notes
| Method | Endpoint             | Access  | Description              |
|--------|----------------------|---------|--------------------------|
| GET    | /api/notes           | Private | Get notes (own/all)      |
| POST   | /api/notes           | Private | Create note              |
| GET    | /api/notes/:id       | Private | Get single note          |
| PUT    | /api/notes/:id       | Private | Update note              |
| DELETE | /api/notes/:id       | Private | Delete note              |
| PATCH  | /api/notes/:id/pin   | Private | Toggle pin               |

### Users (Admin Only)
| Method | Endpoint                   | Access | Description          |
|--------|----------------------------|--------|----------------------|
| GET    | /api/users                 | Admin  | Get all users        |
| GET    | /api/users/:id             | Admin  | Get single user      |
| PUT    | /api/users/:id/role        | Admin  | Update role          |
| PATCH  | /api/users/:id/status      | Admin  | Toggle active status |
| DELETE | /api/users/:id             | Admin  | Delete user + notes  |
| GET    | /api/users/:id/notes       | Admin  | Get user's notes     |

---

## 🛠️ Tech Stack

- **Backend:** Node.js, Express.js, MongoDB, Mongoose, JWT, bcryptjs
- **Frontend:** React 18, React Router v6, Axios, react-hot-toast, CSS Modules
- **Auth:** JWT tokens stored in localStorage, auto-attached via Axios interceptor
